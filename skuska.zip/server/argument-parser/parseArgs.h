//
// Created by xchmel28 on 19.10.19.
//
#ifndef ISA_PARSEARGS_H
#define ISA_PARSEARGS_H

int parsePort(int argc, char *argv[]);

#endif //ISA_PARSEARGS_H
