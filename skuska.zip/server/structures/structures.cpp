//
// Created by xchmel28 on 01.11.19.
//

#include "structures.h"

URL errorStruct() {
	URL toReturn;
	toReturn.type = "";
	toReturn.name = "";
	toReturn.id = -1;
	return toReturn;
}