//
// Created by xchmel28 on 19.10.19.
//

#ifndef ISA_ENUMS_H
#define ISA_ENUMS_H

typedef enum {GET, POST, PUT, DELETE, UNKNOWN} requestMethod;

#endif //ISA_ENUMS_H
