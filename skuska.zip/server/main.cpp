
#include <sys/socket.h>
#include <unistd.h>
#include <cstdlib>
#include <netinet/in.h>
#include <cstring>
#include <cerrno>
#include <iostream>
#include <vector>

#include "argument-parser/parseArgs.h"
#include "handlers/get/getHandler.h"
#include "handlers/post/postHandler.h"
#include "handlers/put/putHandler.h"
#include "handlers/delete/deleteHandler.h"
#include "enums/enums.h"
#include "socket-helper/socketHelper.h"
#include "errors/errors.h"


using namespace std;

int main(int argc, char *argv[]) {
    int port;
    if ((port = parsePort(argc, argv)) == -1) {
        errno = EFAULT;
        perror("Parse port");
        exit(EXIT_FAILURE);
    }

    //START OF SOURCE https://medium.com/from-the-scratch/http-server-what-do-you-need-to-know-to-build-a-simple-http-server-from-scratch-d1ef8945e4fa
    int server_fd, new_socket;
    long valread;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Create socket");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);

    memset(address.sin_zero, '\0', sizeof address.sin_zero);


    if (bind(server_fd, (struct sockaddr *) &address, sizeof(address)) < 0) {
        perror("Binding");
        exit(EXIT_FAILURE);
    }
    if (listen(server_fd, 10) < 0) {
        perror("Listen");
        exit(EXIT_FAILURE);
    }

    map<string, vector<string>> db;

    while (1) {
        printf("\n+++++++ Waiting for new connection ++++++++\n\n");
        if ((new_socket = accept(server_fd, (struct sockaddr *) &address, (socklen_t *) &addrlen)) < 0) {
            perror("In accept");
            exit(EXIT_FAILURE);
        }
// END OF SOURCE
//
//              READING THE WHOLE MESSAGE IF IS BIGGER THAN BUFSIZE TODO
//
//        int *request = (int *)malloc(sizeof(int)*BUFSIZ);
//        int readingCicle = 1;
//        int bytesRead = 0;
//        bytesRead = read(new_socket, request, BUFSIZ);
//        if (bytesRead == BUFSIZ){
//            int lastBytesInSocket = 0;
//            while( lastBytesInSocket = read(new_socket, request, BUFSIZ) <= BUFSIZ ){
//                readingCicle += 1;
//                request = (int *)realloc(request, sizeof(int)*BUFSIZ*readingCicle);
//            }
//            bytesRead = (bytesRead * readingCicle) + lastBytesInSocket;
//        }
//
//        string daco = stringz(request);
//        char wholeRequest[BUFSIZ*readingCicle] = *request;
//      DONT FORGET TO FREE THE POINTER

        char request[BUFSIZ];
        read(new_socket, request, BUFSIZ);
        printf("%s\n", request);


		if (checkProtocol(request) != 0){
			errors::sendErrorBadRequest(new_socket);
			close(new_socket);
			cout<<"CYBA";
			continue;
		}

        requestMethod method = getMethod(request);

        if (method == GET) {
             if ( getHandler::serve(request, new_socket, db) < 0 ){
				 cout<<"Error serving request\n";
             }
        } else if (method == POST) {
             if ( postHandler::serve(request, new_socket, db) <= 0 ){
				 cout<<"Error serving request\n";
             }
        } else if (method == PUT) {
            if ( putHandler::serve(request, new_socket, db) <= 0 ){
				cout<<"Error serving request\n";
            }
        } else if (method == DELETE) {
            if ( deleteHandler::serve(request, new_socket, db) < 0 ){
				cout<<"Error serving request\n";
            }
        } else {
			if ( serveUnsupported(new_socket) < 0 ) {
				cout<<"Error serving request\n";
			}
        }

        cout<< "\n\n";
        for(auto elem : db)
        {
            std::cout << elem.first <<  " " << elem.second.size() << "\n";
        }

        //pories free ak bude viac krat potrebne citat
        std::fill_n(request, BUFSIZ, 0);
        close(new_socket);
    }
    return 0;
}

