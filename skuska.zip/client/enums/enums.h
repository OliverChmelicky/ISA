//
// Created by olo on 28.10.19.
//

#ifndef ISA_ENUMS_H
#define ISA_ENUMS_H

typedef enum {BOARDS, BOARD, ITEM} type;
typedef enum {ADD, DELETE, LIST, UPDATE} operation;

#endif //ISA_ENUMS_H
